-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2019 at 08:32 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `serurex`
--

-- --------------------------------------------------------

--
-- Table structure for table `api_tokens`
--

CREATE TABLE `api_tokens` (
  `id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `VoteCode` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capital` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `citizenship` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_sub_unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iso_3166_2` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `iso_3166_3` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `region_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sub_region_code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `eea` tinyint(1) NOT NULL DEFAULT '0',
  `calling_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `VoteCode`, `capital`, `citizenship`, `country_code`, `currency`, `currency_code`, `currency_sub_unit`, `currency_symbol`, `full_name`, `iso_3166_2`, `iso_3166_3`, `name`, `region_code`, `sub_region_code`, `eea`, `calling_code`, `flag`) VALUES
('001', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Office of the President', '', '', 0, NULL, NULL),
('002', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'State House', '', '', 0, NULL, NULL),
('003', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Office of the Prime Minister', '', '', 0, NULL, NULL),
('004', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Defence', '', '', 0, NULL, NULL),
('005', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Public Service', '', '', 0, NULL, NULL),
('006', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Foreign Affairs', '', '', 0, NULL, NULL),
('007', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Justice and Constitutional Affairs', '', '', 0, NULL, NULL),
('008', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Finance, Planning & Economic Dev.', '', '', 0, NULL, NULL),
('009', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Internal Affairs', '', '', 0, NULL, NULL),
('010', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Agriculture, Animal & Fisheries', '', '', 0, NULL, NULL),
('011', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Local Government', '', '', 0, NULL, NULL),
('012', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Lands, Housing & Urban Development', '', '', 0, NULL, NULL),
('013', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Education and Sports', '', '', 0, NULL, NULL),
('014', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Health', '', '', 0, NULL, NULL),
('015', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Trade, Industry and Cooperatives', '', '', 0, NULL, NULL),
('016', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Works and Transport', '', '', 0, NULL, NULL),
('017', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Energy and Mineral Development', '', '', 0, NULL, NULL),
('018', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Gender, Labour and Social Development', '', '', 0, NULL, NULL),
('019', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Water and Environment', '', '', 0, NULL, NULL),
('020', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of ICT and National Guidance', '', '', 0, NULL, NULL),
('021', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'East African Community', '', '', 0, NULL, NULL),
('022', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Tourism, Wildlife and Antiquities', '', '', 0, NULL, NULL),
('023', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ministry of Science,Technology and Innovation', '', '', 0, NULL, NULL),
('101', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Judiciary', '', '', 0, NULL, NULL),
('102', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Electoral Commission', '', '', 0, NULL, NULL),
('103', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Inspectorate of Government (IG)', '', '', 0, NULL, NULL),
('104', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Parliamentary Commission', '', '', 0, NULL, NULL),
('105', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Law Reform Commission', '', '', 0, NULL, NULL),
('106', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Human Rights Commission', '', '', 0, NULL, NULL),
('107', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda AIDS Commission', '', '', 0, NULL, NULL),
('108', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Planning Authority', '', '', 0, NULL, NULL),
('109', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Law Development Centre', '', '', 0, NULL, NULL),
('110', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Industrial Research Institute', '', '', 0, NULL, NULL),
('111', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Busitema University', '', '', 0, NULL, NULL),
('112', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Ethics and Integrity', '', '', 0, NULL, NULL),
('113', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda National Roads Authority', '', '', 0, NULL, NULL),
('114', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Cancer Institute', '', '', 0, NULL, NULL),
('115', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Heart Institute', '', '', 0, NULL, NULL),
('116', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Medical Stores', '', '', 0, NULL, NULL),
('117', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Tourism Board', '', '', 0, NULL, NULL),
('118', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Road Fund', '', '', 0, NULL, NULL),
('119', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Registration Services Bureau', '', '', 0, NULL, NULL),
('120', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Citizenship and Immigration Control', '', '', 0, NULL, NULL),
('121', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Dairy Development Authority', '', '', 0, NULL, NULL),
('122', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Kampala Capital City Authority', '', '', 0, NULL, NULL),
('123', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Rural Electrification Agency (REA)', '', '', 0, NULL, NULL),
('124', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Equal Opportunities Commission', '', '', 0, NULL, NULL),
('125', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Animal Genetic Res. Centre and Data Bank', '', '', 0, NULL, NULL),
('126', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Information Technology Authority', '', '', 0, NULL, NULL),
('127', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Muni University', '', '', 0, NULL, NULL),
('128', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda National Examinations Board', '', '', 0, NULL, NULL),
('129', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Financial Intelligence Authority (FIA)', '', '', 0, NULL, NULL),
('131', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Auditor General', '', '', 0, NULL, NULL),
('132', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Education Service Commission', '', '', 0, NULL, NULL),
('133', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Office of the Director of Public Prosecutions', '', '', 0, NULL, NULL),
('134', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Health Service Commission', '', '', 0, NULL, NULL),
('136', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Makerere University', '', '', 0, NULL, NULL),
('137', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mbarara University', '', '', 0, NULL, NULL),
('138', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Makerere University Business School', '', '', 0, NULL, NULL),
('139', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Kyambogo University', '', '', 0, NULL, NULL),
('140', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Management Institute', '', '', 0, NULL, NULL),
('141', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'URA', '', '', 0, NULL, NULL),
('142', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Agricultural Research Organisation', '', '', 0, NULL, NULL),
('143', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Bureau of Statistics', '', '', 0, NULL, NULL),
('144', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Police Force', '', '', 0, NULL, NULL),
('145', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Prisons', '', '', 0, NULL, NULL),
('146', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Public Service Commission', '', '', 0, NULL, NULL),
('147', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Local Government Finance Commission', '', '', 0, NULL, NULL),
('148', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Judicial Service Commission', '', '', 0, NULL, NULL),
('149', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Gulu University', '', '', 0, NULL, NULL),
('150', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Environment Management Authority', '', '', 0, NULL, NULL),
('151', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Blood Transfusion Service (UBTS)', '', '', 0, NULL, NULL),
('152', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'NAADS Secretariat', '', '', 0, NULL, NULL),
('153', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'PPDA', '', '', 0, NULL, NULL),
('154', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda National Bureau of Standards', '', '', 0, NULL, NULL),
('155', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Cotton Development Organisation', '', '', 0, NULL, NULL),
('156', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Land Commission', '', '', 0, NULL, NULL),
('157', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Forestry Authority', '', '', 0, NULL, NULL),
('159', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'External Security Organisation', '', '', 0, NULL, NULL),
('160', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Coffee Development Authority', '', '', 0, NULL, NULL),
('161', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mulago Hospital Complex', '', '', 0, NULL, NULL),
('162', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Butabika Hospital', '', '', 0, NULL, NULL),
('163', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Arua Referral Hospital', '', '', 0, NULL, NULL),
('164', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Fort Portal Referral Hospital', '', '', 0, NULL, NULL),
('165', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Gulu Referral Hospital', '', '', 0, NULL, NULL),
('166', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Hoima Referral Hospital', '', '', 0, NULL, NULL),
('167', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Jinja Referral Hospital', '', '', 0, NULL, NULL),
('168', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Kabale Referral Hospital', '', '', 0, NULL, NULL),
('169', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Masaka Referral Hospital', '', '', 0, NULL, NULL),
('170', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mbale Referral Hospital', '', '', 0, NULL, NULL),
('171', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Soroti Referral Hospital', '', '', 0, NULL, NULL),
('172', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Lira Referral Hospital', '', '', 0, NULL, NULL),
('173', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mbarara Referral Hospital', '', '', 0, NULL, NULL),
('174', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mubende Referral Hospital', '', '', 0, NULL, NULL),
('175', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Moroto Referral Hospital', '', '', 0, NULL, NULL),
('176', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Naguru Referral Hospital', '', '', 0, NULL, NULL),
('201', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in New York', '', '', 0, NULL, NULL),
('202', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in England', '', '', 0, NULL, NULL),
('203', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Canada', '', '', 0, NULL, NULL),
('204', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in India', '', '', 0, NULL, NULL),
('205', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Egypt', '', '', 0, NULL, NULL),
('206', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Kenya', '', '', 0, NULL, NULL),
('207', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Tanzania', '', '', 0, NULL, NULL),
('208', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Nigeria', '', '', 0, NULL, NULL),
('209', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in South Africa', '', '', 0, NULL, NULL),
('210', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Washington', '', '', 0, NULL, NULL),
('211', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Ethiopia', '', '', 0, NULL, NULL),
('212', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in China', '', '', 0, NULL, NULL),
('213', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Rwanda', '', '', 0, NULL, NULL),
('214', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Geneva', '', '', 0, NULL, NULL),
('215', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Japan', '', '', 0, NULL, NULL),
('216', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Libya', '', '', 0, NULL, NULL),
('217', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Saudi Arabia', '', '', 0, NULL, NULL),
('218', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Denmark', '', '', 0, NULL, NULL),
('219', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Belgium', '', '', 0, NULL, NULL),
('220', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Italy', '', '', 0, NULL, NULL),
('221', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in DR Congo', '', '', 0, NULL, NULL),
('223', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Sudan', '', '', 0, NULL, NULL),
('224', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in France', '', '', 0, NULL, NULL),
('225', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Germany', '', '', 0, NULL, NULL),
('226', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Iran', '', '', 0, NULL, NULL),
('227', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Russia', '', '', 0, NULL, NULL),
('228', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Canberra', '', '', 0, NULL, NULL),
('229', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Juba', '', '', 0, NULL, NULL),
('230', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Abu Dhabi ', '', '', 0, NULL, NULL),
('231', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Bujumbura', '', '', 0, NULL, NULL),
('232', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Consulate in Guangzhou', '', '', 0, NULL, NULL),
('233', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Ankara', '', '', 0, NULL, NULL),
('234', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Somalia', '', '', 0, NULL, NULL),
('235', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Mission in Malyasia', '', '', 0, NULL, NULL),
('236', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Consulate in Mombasa', '', '', 0, NULL, NULL),
('301', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Lira University', '', '', 0, NULL, NULL),
('302', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda National Meteorological Authority', '', '', 0, NULL, NULL),
('303', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Curriculum Development Centre', '', '', 0, NULL, NULL),
('304', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Virus Research Institute (UVRI)', '', '', 0, NULL, NULL),
('305', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Directorate of Government Analytical Laboratory', '', '', 0, NULL, NULL),
('306', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Uganda Export Promotion Board', '', '', 0, NULL, NULL),
('307', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Kabale University', '', '', 0, NULL, NULL),
('308', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'Soroti University', '', '', 0, NULL, NULL),
('309', '', NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, '', '', 'National Identification and Registration Authority (NIRA)', '', '', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2015_08_25_172600_create_settings_table', 1),
(3, '2015_09_19_191655_setup_countries_table', 1),
(4, '2015_10_10_170827_create_users_table', 1),
(5, '2015_10_10_171049_create_social_login_table', 1),
(6, '2015_12_24_080704_setup_authorization_tables', 1),
(7, '2015_12_24_152327_create_sessions_table', 1),
(8, '2015_12_29_224252_create_user_activity_table', 1),
(9, '2015_12_30_171734_add_foreign_keys', 1),
(10, '2017_04_13_200254_create_api_tokens_table', 1),
(11, '2018_09_03_142544_add__i_p_p_s_field_to_users_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `removable` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`, `removable`, `created_at`, `updated_at`) VALUES
(1, 'users.manage', 'Manage Users', 'Manage users and their sessions.', 0, '2018-08-28 14:28:41', '2018-08-28 14:28:41'),
(2, 'users.activity', 'View System Activity Log', 'View activity log for all system users.', 0, '2018-08-28 14:28:41', '2018-08-28 14:28:41'),
(3, 'roles.manage', 'Manage Roles', 'Manage system roles.', 0, '2018-08-28 14:28:41', '2018-08-28 14:28:41'),
(4, 'permissions.manage', 'Manage Permissions', 'Manage role permissions.', 0, '2018-08-28 14:28:41', '2018-08-28 14:28:41'),
(5, 'settings.general', 'Update General System Settings', '', 0, '2018-08-28 14:28:41', '2018-08-28 14:28:41'),
(6, 'settings.auth', 'Update Authentication Settings', 'Update authentication and registration system settings.', 0, '2018-08-28 14:28:41', '2018-08-28 14:28:41'),
(7, 'settings.notifications', 'Update Notifications Settings', '', 0, '2018-08-28 14:28:41', '2018-08-28 14:28:41'),
(9, 'Inspect.mdalg', 'Inspect MDA/LG', 'Self Inspect MDA/LG', 1, '2019-02-16 18:21:58', '2019-02-16 18:26:54'),
(10, 'inspect.political', 'Inspect Political', 'Inspect Politically and Score', 1, '2019-02-16 18:26:20', '2019-02-16 18:26:20'),
(11, 'inspect.joint', 'Carry out Joint Inspection', 'Carry out Joint Inspection', 1, '2019-02-16 18:29:37', '2019-02-16 18:29:37'),
(12, 'Inspect.Manage.Questions', 'Manage Inspection Questions', 'Manage Inspection Questions', 1, '2019-02-16 19:04:44', '2019-02-16 19:05:07'),
(13, 'hr_analytics.view', 'HR Analytics View', 'HR Analytics View', 1, '2019-02-17 05:55:20', '2019-02-17 05:55:20'),
(14, 'hr_analytics.manage', 'HR Analytics Manage', 'HR Analytics Manage', 1, '2019-02-17 05:56:05', '2019-02-17 05:56:05'),
(15, 'Inspect.Basic', 'Inspect Basic View', 'Basic Inspect Functions', 1, '2019-02-17 11:28:20', '2019-02-17 11:29:32');

-- --------------------------------------------------------

--
-- Table structure for table `permission_levels`
--

CREATE TABLE `permission_levels` (
  `PID` int(11) NOT NULL,
  `Permission` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `permission_levels`
--

INSERT INTO `permission_levels` (`PID`, `Permission`) VALUES
(0, 'No Access'),
(1, 'View'),
(2, 'View / Edit'),
(3, 'View / Edit / Add'),
(4, 'View / Edit / Add / Delete');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(9, 1),
(9, 3),
(10, 1),
(10, 4),
(11, 1),
(11, 5),
(11, 6),
(12, 1),
(12, 6),
(13, 1),
(14, 1),
(15, 1),
(15, 3),
(15, 4),
(15, 5),
(15, 6);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `removable` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `removable`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'Admin', 'System administrator.', 0, '2018-08-28 14:28:41', '2018-08-28 14:28:41'),
(2, 'User', 'User', 'Default system user.', 0, '2018-08-28 14:28:41', '2018-08-28 14:28:41'),
(3, 'Inspect.MDALG', 'Inspect MDALG', 'Carry out Inspection in MDA/LG', 1, '2019-02-16 18:16:49', '2019-02-17 16:03:03'),
(4, 'Inspect.Political', 'Inspect Political', 'Political Leader', 1, '2019-02-16 18:24:05', '2019-02-17 16:03:17'),
(5, 'Inspection.Team', 'Inspection Team', 'Joint Inspection Team', 1, '2019-02-16 18:28:24', '2019-02-17 16:03:27'),
(6, 'Inspect.Manager', 'Inspect Manager', 'Inspect Manager', 1, '2019-02-17 05:34:53', '2019-02-17 05:34:53');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('r7d91JfywzZufKvdiohwVeWWrXewk3zUiBCLDMwm', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSGV4V3g2eVU3bEJDZ1NsclphdU1mT3lER1hDVDAxbHhlN0RYS3dreiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly9sb2NhbGhvc3QvZGFzaC9zZWN1cmV4L3B1YmxpYyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==', 1550422248),
('vpR8Bxcpd4j47ZzURUCgP5WofPJU3kmpIuYVuCR2', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiOThIRDBqclA0aFpxZWZDeUVQdzVIbnVBWm9NZXY2WG52aFVQbUVMOCI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjQ3OiJodHRwOi8vbG9jYWxob3N0L2Rhc2gvc2VjdXJleC9wdWJsaWMvcGVybWlzc2lvbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1550430225),
('Z5CxDDcSckUa8u9afvH0NkP4T6nYUZnE8deHEXar', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMEhzSDd6VW9CVzhrZUlEOVAySWRDTkNjWWNtQU9LVHEyVkNJVGtSUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Nzg6Imh0dHA6Ly9sb2NhbGhvc3QvZGFzaC9zZWN1cmV4L3B1YmxpYy9sb2dpbj90bz1odHRwJTNBJTJGJTJGbG9jYWxob3N0JTJGZGFzaCUyRiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==', 1550429635);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `social_logins`
--

CREATE TABLE `social_logins` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userlevel` int(1) NOT NULL DEFAULT '1',
  `VoteCode` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '007',
  `VoteName` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Ministry/Agency/Local Government',
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '135px-Coat_of_arms_of_Uganda.svg.png',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `birthday` date DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `confirmation_token` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_country_code` int(11) DEFAULT NULL,
  `two_factor_phone` int(11) DEFAULT NULL,
  `two_factor_options` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `Strategic_Projects` int(2) NOT NULL DEFAULT '1',
  `Strategic_Actions` int(2) NOT NULL DEFAULT '1',
  `inspection_performance` int(1) NOT NULL DEFAULT '0',
  `Strategic_Data` int(2) NOT NULL DEFAULT '1',
  `Govt_Performance` int(2) NOT NULL DEFAULT '1',
  `General_Information` int(2) NOT NULL DEFAULT '1',
  `Reports` int(2) NOT NULL DEFAULT '1',
  `IPPS_Number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`, `first_name`, `last_name`, `phone`, `userlevel`, `VoteCode`, `VoteName`, `avatar`, `address`, `country_id`, `role_id`, `birthday`, `last_login`, `confirmation_token`, `status`, `two_factor_country_code`, `two_factor_phone`, `two_factor_options`, `remember_token`, `created_at`, `updated_at`, `Strategic_Projects`, `Strategic_Actions`, `inspection_performance`, `Strategic_Data`, `Govt_Performance`, `General_Information`, `Reports`, `IPPS_Number`) VALUES
(1, 'patrick.mundua@gmail.com', 'admin', '$2y$10$s9RIi0pVv9kZzAASkJh9gOEwEm3LDkZtmubGT0Lq3kiEzi9LIjrdy', 'Patrick', 'Mundua', '+256757938888', 10, '005', 'Ministry of Public Service', 'QhaoaXOu1tMg0xYD.png', 'P. O. Box 21417, Kampala', '020', 1, '1978-01-11', '2019-02-17 15:53:14', NULL, 'Active', NULL, NULL, NULL, 'V1V39B1wb4LneIROiqU6SRglSmgRdaP5AKt18EVuvRZkv95ylFBO13RixvS7', '2018-08-28 14:28:41', '2019-02-17 15:53:14', 5, 5, 1, 5, 5, 1, 5, '12345'),
(2, 'mundua_@live.com', 'musoke', '$2y$10$RnpuxUjKGAceWvg8DrtygOOavUJqwcY0Jbo7B50ynsPW/jPZokYFK', 'Henry', 'Musoke', NULL, 1, '005', 'Ministry of Public Service', 'zLlJjgebmB5KH9SK.png', NULL, '018', 2, '1978-01-11', '2019-02-17 11:19:46', NULL, 'Active', NULL, NULL, NULL, NULL, '2018-08-28 16:04:36', '2019-02-17 11:26:29', 2, 3, 1, 1, 2, 1, 1, ''),
(3, 'twinocharles@gmail.com', 'twino', '$2y$10$DS3cMrnNgtu7nftN4sRXE.hYuqGBfbl/l4MkYJyUigPlLLgKyRx3u', 'Twinomugisha', 'Charles', '757938888', 1, '007', 'Ministry/Agency/Local Government', '135px-Coat_of_arms_of_Uganda.svg.png', 'P. O. Box 21417, Kampala', '005', 3, '2010-02-01', '2019-02-17 15:53:55', NULL, 'Active', NULL, NULL, NULL, 'XpoRvfELN7si0QcEIy9IrFzbGPyB51oATG8WiBxKBHMmEWqCB6noEQ3GfFpH', '2019-02-14 05:55:31', '2019-02-17 15:53:55', 0, 0, 3, 0, 0, 1, 1, '12345');

-- --------------------------------------------------------

--
-- Table structure for table `user_activity`
--

CREATE TABLE `user_activity` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_activity`
--

INSERT INTO `user_activity` (`id`, `description`, `user_id`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 14:30:32'),
(2, 'Updated profile details.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 14:47:30'),
(3, 'Updated profile avatar.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 14:58:49'),
(4, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:00:53'),
(5, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:01:31'),
(6, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:04:13'),
(7, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:05:11'),
(8, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:18:34'),
(9, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:18:44'),
(10, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:30:18'),
(11, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:30:33'),
(12, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:38:36'),
(13, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:45:07'),
(14, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:45:20'),
(15, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:48:19'),
(16, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:52:39'),
(17, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:52:56'),
(18, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:55:12'),
(19, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 15:55:23'),
(20, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 17:03:11'),
(21, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 17:53:34'),
(22, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 18:03:37'),
(23, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 18:05:01'),
(24, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 18:06:22'),
(25, 'Updated profile avatar.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 18:15:41'),
(26, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 19:11:32'),
(27, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-28 19:59:01'),
(28, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-29 07:05:27'),
(29, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-29 07:40:55'),
(30, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-29 07:41:06'),
(31, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-29 07:41:25'),
(32, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-29 07:41:33'),
(33, 'Logged out.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-29 07:47:36'),
(34, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-29 16:01:05'),
(35, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-30 11:48:19'),
(36, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-31 09:26:00'),
(37, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-31 11:35:02'),
(38, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-31 11:53:28'),
(39, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-31 11:54:32'),
(40, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-31 11:57:08'),
(41, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-31 11:58:49'),
(42, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-31 12:00:11'),
(43, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-08-31 12:59:20'),
(44, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 07:07:57'),
(45, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 09:59:56'),
(46, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 10:39:51'),
(47, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 10:41:01'),
(48, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 10:41:24'),
(49, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 10:41:41'),
(50, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:07:05'),
(51, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:07:16'),
(52, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:14:59'),
(53, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:19:05'),
(54, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:19:14'),
(55, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:19:28'),
(56, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:19:41'),
(57, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:22:23'),
(58, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:22:58'),
(59, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:38:58'),
(60, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:43:10'),
(61, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 11:58:10'),
(62, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 13:23:26'),
(63, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 13:47:45'),
(64, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 13:53:06'),
(65, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 13:53:16'),
(66, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 14:00:52'),
(67, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 14:05:57'),
(68, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 15:25:32'),
(69, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 15:33:00'),
(70, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 16:31:53'),
(71, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-01 18:39:44'),
(72, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-02 04:21:53'),
(73, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-02 06:54:21'),
(74, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-02 06:57:47'),
(75, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-02 07:03:31'),
(76, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-02 07:03:51'),
(77, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-02 07:31:55'),
(78, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-02 08:11:44'),
(79, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-02 09:15:21'),
(80, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-02 09:15:35'),
(81, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 04:37:33'),
(82, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 06:09:42'),
(83, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 06:40:54'),
(84, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 06:52:43'),
(85, 'Updated website settings.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 06:54:08'),
(86, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 07:16:41'),
(87, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 07:33:33'),
(88, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 07:35:46'),
(89, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 08:00:34'),
(90, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 08:56:27'),
(91, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 11:33:55'),
(92, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 11:37:50'),
(93, 'Updated profile details.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 11:45:04'),
(94, 'Updated profile details.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 12:27:03'),
(95, 'Updated profile details.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 12:32:33'),
(96, 'Updated profile details.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 13:02:16'),
(97, 'Updated profile details.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 13:09:45'),
(98, 'Updated profile details.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 13:11:18'),
(99, 'Updated profile details.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 13:11:27'),
(100, 'Updated profile details.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 13:16:32'),
(101, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 16:54:16'),
(102, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 17:02:43'),
(103, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 17:06:31'),
(104, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-03 17:25:10'),
(105, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-04 17:20:06'),
(106, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-04 18:06:04'),
(107, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 02:34:45'),
(108, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 05:47:46'),
(109, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 05:51:01'),
(110, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 05:51:09'),
(111, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 07:52:03'),
(112, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 07:55:53'),
(113, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 08:57:27'),
(114, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 08:58:38'),
(115, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 09:11:20'),
(116, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 09:24:49'),
(117, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 09:32:49'),
(118, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 09:39:09'),
(119, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 09:42:24'),
(120, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 09:50:03'),
(121, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 10:30:34'),
(122, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 10:32:45'),
(123, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 11:17:14'),
(124, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 11:18:55'),
(125, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 11:24:27'),
(126, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 11:26:47'),
(127, 'Updated profile avatar.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 11:31:31'),
(128, 'Updated profile avatar.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 11:35:43'),
(129, 'Updated profile details.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 11:35:47'),
(130, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 11:43:26'),
(131, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 11:53:48'),
(132, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-05 15:05:35'),
(133, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-06 13:17:32'),
(134, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-06 15:25:00'),
(135, 'Logged out.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-06 15:25:00'),
(136, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-06 15:25:11'),
(137, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 08:37:52'),
(138, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 09:36:43'),
(139, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 09:37:50'),
(140, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 09:45:23'),
(141, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 09:54:50'),
(142, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 10:05:01'),
(143, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 10:17:21'),
(144, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 10:51:54'),
(145, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 11:03:25'),
(146, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 11:10:55'),
(147, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 11:22:26'),
(148, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 11:29:04'),
(149, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 11:38:27'),
(150, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 12:44:05'),
(151, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 12:48:01'),
(152, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 12:50:05'),
(153, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-07 13:35:22'),
(154, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-08 06:56:33'),
(155, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-08 09:04:51'),
(156, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-08 09:28:25'),
(157, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-09 16:55:30'),
(158, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-09 18:56:31'),
(159, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-09 19:30:52'),
(160, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-10 10:13:23'),
(161, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-10 10:35:41'),
(162, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-10 13:59:15'),
(163, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-10 14:56:02'),
(164, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-10 14:56:10'),
(165, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-10 15:41:34'),
(166, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-11 09:52:44'),
(167, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-11 14:52:06'),
(168, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-18 04:11:43'),
(169, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-19 11:52:32'),
(170, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36', '2018-09-19 12:07:33'),
(171, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-09 14:33:10'),
(172, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-09 16:34:23'),
(173, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-14 05:36:05'),
(174, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-14 08:25:26'),
(175, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-14 09:04:10'),
(176, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-14 09:07:32'),
(177, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-16 13:38:09'),
(178, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-16 14:35:04'),
(179, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-16 14:36:49'),
(180, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-16 14:43:59'),
(181, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-16 14:51:57'),
(182, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-16 16:01:21'),
(183, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-19 14:23:16'),
(184, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-22 07:21:17'),
(185, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-22 07:28:19'),
(186, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-22 08:15:15'),
(187, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-22 08:35:50'),
(188, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-22 08:49:44'),
(189, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-22 09:38:46'),
(190, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-22 11:42:40'),
(191, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 10:15:17'),
(192, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 11:21:58'),
(193, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 12:31:25'),
(194, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 12:53:07'),
(195, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 13:35:07'),
(196, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 13:42:06'),
(197, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 13:56:54'),
(198, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 14:01:31'),
(199, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 17:20:28'),
(200, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-24 18:47:23'),
(201, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-25 08:16:14'),
(202, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-25 11:24:04'),
(203, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-25 13:47:01'),
(204, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-25 14:56:15'),
(205, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-25 14:56:24'),
(206, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-26 04:40:26'),
(207, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-26 10:05:19'),
(208, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-26 10:19:28'),
(209, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-26 12:22:01'),
(210, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-26 12:36:39'),
(211, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-26 14:50:22'),
(212, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-27 04:43:11'),
(213, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-27 06:54:15'),
(214, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-28 09:41:14'),
(215, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-28 12:50:12'),
(216, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36', '2018-10-31 14:11:12'),
(217, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36', '2018-11-01 09:59:50'),
(218, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36', '2018-11-01 13:07:20'),
(219, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36', '2018-11-02 10:44:17'),
(220, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36', '2018-11-02 13:12:09'),
(221, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36', '2018-11-08 12:26:02'),
(222, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36', '2018-11-18 08:17:51'),
(223, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36', '2018-12-01 10:01:04'),
(224, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36', '2018-12-04 14:46:28'),
(225, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36', '2018-12-11 12:28:23'),
(226, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36', '2018-12-12 09:54:01'),
(227, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2018-12-31 14:47:49'),
(228, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-20 06:26:10'),
(229, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-20 07:57:38'),
(230, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-20 08:01:54'),
(231, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-20 08:30:42'),
(232, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-20 08:47:53'),
(233, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-20 08:51:42'),
(234, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-22 12:31:04'),
(235, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-22 14:43:45'),
(236, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-26 09:50:22'),
(237, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-01-30 13:42:55'),
(238, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-04 11:51:10'),
(239, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-04 16:19:06'),
(240, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-05 06:20:07'),
(241, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-05 08:34:26'),
(242, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-06 13:58:00'),
(243, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-06 15:56:45'),
(244, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-12 12:57:05'),
(245, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-12 13:47:42'),
(246, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-12 14:03:30'),
(247, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-12 14:45:02'),
(248, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-12 16:56:20'),
(249, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-13 08:08:54'),
(250, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-13 08:26:54'),
(251, 'Created new permission called District Inspector.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-13 08:34:15'),
(252, 'Updated the permission named District Inspector.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-13 08:34:51'),
(253, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-13 12:13:00'),
(254, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-13 12:18:05'),
(255, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-13 15:49:22'),
(256, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-14 05:50:28'),
(257, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-14 05:56:35'),
(258, 'Logged in.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-14 05:56:48'),
(259, 'Logged out.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-14 06:16:02'),
(260, 'Logged in.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36', '2019-02-14 06:16:17'),
(261, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-15 06:39:35'),
(262, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 13:12:22'),
(263, 'Logged in.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 13:44:36'),
(264, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 13:56:53'),
(265, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:02:11'),
(266, 'Deleted permission named District Inspector.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:15:27'),
(267, 'Created new role called MDA/LG Inspector.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:16:49'),
(268, 'Updated profile details for Twinomugisha Charles.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:19:23'),
(269, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:20:30'),
(270, 'Created new permission called Inspect MDA/LG.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:21:58'),
(271, 'Created new role called Political Leader.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:24:05'),
(272, 'Created new permission called Inspect Political.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:26:20'),
(273, 'Updated the permission named Inspect MDA/LG.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:26:54'),
(274, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:27:18'),
(275, 'Created new role called Joint Inspection Team.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:28:24'),
(276, 'Created new permission called Carry out Joint Inspection.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:29:37'),
(277, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:29:59'),
(278, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:42:41'),
(279, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:43:51'),
(280, 'Updated role with name MDA/LG Inspector.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:45:59'),
(281, 'Updated role with name Political Leader.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:46:31'),
(282, 'Updated role with name Joint Inspection Team.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:46:56'),
(283, 'Updated role with name Joint Inspection Team.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:47:28'),
(284, 'Updated role with name Inspect.MDALG.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:48:19'),
(285, 'Updated role with name Inspect.Political.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:48:31'),
(286, 'Updated role with name Inspection.Team.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 18:48:42');
INSERT INTO `user_activity` (`id`, `description`, `user_id`, `ip_address`, `user_agent`, `created_at`) VALUES
(287, 'Created new permission called Inspect.Manage.Questions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 19:04:44'),
(288, 'Updated the permission named Manage Inspection Questions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 19:05:07'),
(289, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-16 19:05:21'),
(290, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 04:43:34'),
(291, 'Created new role called Inspect Manager.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 05:34:53'),
(292, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 05:35:09'),
(293, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 05:35:16'),
(294, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 05:53:33'),
(295, 'Created new permission called HR Analytics View.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 05:55:20'),
(296, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 05:55:32'),
(297, 'Created new permission called HR Analytics Manage.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 05:56:05'),
(298, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 05:56:37'),
(299, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 06:03:17'),
(300, 'Logged out.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 06:05:58'),
(301, 'Logged in.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 06:06:10'),
(302, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 06:16:01'),
(303, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 09:13:38'),
(304, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:04:00'),
(305, 'Logged in.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:04:12'),
(306, 'Logged out.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:19:38'),
(307, 'Logged in.', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:19:46'),
(308, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:26:37'),
(309, 'Created new permission called Inspect.Basic.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:28:20'),
(310, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:28:52'),
(311, 'Updated the permission named Inspect Basic View.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:29:32'),
(312, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:38:37'),
(313, 'Logged in.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 11:39:05'),
(314, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 12:46:40'),
(315, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 13:50:23'),
(316, 'Logged out.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 13:50:36'),
(317, 'Logged in.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 13:50:48'),
(318, 'Logged in.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 15:53:14'),
(319, 'Logged in.', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 15:53:55'),
(320, 'Updated role permissions.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 15:58:28'),
(321, 'Updated role with name Inspect MDALG.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 16:03:03'),
(322, 'Updated role with name Inspect Political.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 16:03:17'),
(323, 'Updated role with name Inspection Team.', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36', '2019-02-17 16:03:27');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `ID` int(11) NOT NULL,
  `SectorCode` varchar(255) DEFAULT NULL,
  `VoteCode` varchar(255) DEFAULT NULL,
  `VoteName` varchar(255) DEFAULT NULL,
  `MDAType` double DEFAULT NULL,
  `VoteMission` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`ID`, `SectorCode`, `VoteCode`, `VoteName`, `MDAType`, `VoteMission`) VALUES
(1, '11', '001', 'Office of the President', 1, 'To generate and provide intelligence for pre-emption of internal security threats to the State.'),
(2, '16', '001', 'Office of the President', 1, '\"To provide Leadership in Public Policy Management and Good Governance for National Development.\"'),
(3, '16', '002', 'State House', 1, 'To provide at all times, support to the Presidency, in order to facilitate effective and efficient performance of its constitutional and administrative responsibilities, and to cater for the welfare and security of H.E the President, the Vice President and their immediate families.\n'),
(4, '13', '003', 'Office of the Prime Minister', 1, 'A Coordinated, Responsive and Accountable Government for Socio-Economic Transformation'),
(5, '11', '004', 'Ministry of Defence', 1, 'The mandate of the Ministry of Defence is derived from the Constitution of Republic of Uganda 1995. In accordance with Articles 208 and 209, the UPDF is established and mandated to carry out the following functions;\n\na)	Defend and protect the sovereignty and territorial integrity of Uganda. \nb)	Cooperate with civilian authorities in emergency situations and in cases of natural disasters.\nc)	Foster harmony and understanding between Defence forces and civilians.\nd)	Engage in productive activities for National development.\n'),
(6, '13', '005', 'Ministry of Public Service', 1, '“To provide human resource policies, management systems and structures for an effective and efficient public service that facilitates national development”.'),
(7, '16', '006', 'Ministry of Foreign Affairs', 1, 'To promote and protect Uganda\'s national interests abroad'),
(8, '12', '007', 'Ministry of Justice and Constitutional Affairs', 1, 'To provide legal advice and legal services as well as supporting the machinery that provides the legal framework for good governance.'),
(9, '14', '008', 'Ministry of Finance, Planning & Economic Dev.', 1, 'To formulate sound economic policies, maximize revenue mobilization, ensure efficient allocation and accountability for public resources so as to ensure sustainable economic growth and development.'),
(10, '12', '009', 'Ministry of Internal Affairs', 1, 'To ensure and maintain internal security, peace and stability'),
(11, '01', '010', 'Ministry of Agriculture, Animal & Fisheries', 1, 'Transforming the sector from subsistence farming to commercial agriculture'),
(12, '13', '011', 'Ministry of Local Government', 1, 'To coordinate and support LGs in a bid to provide efficient and sustainable services, improve the welfare of the people and eradicate poverty. '),
(13, '02', '012', 'Ministry of Lands, Housing & Urban Development', 1, 'The Mission is “To ensure sustainable land management, planned urban and rural development and decent housing for all”.'),
(14, '07', '013', 'Ministry of Education and Sports', 1, 'To provide for, support, guide, coordinate, regulate and promote quality education and sports to all persons in Uganda for national integration, individual and national development.'),
(15, '08', '014', 'Ministry of Health', 1, 'To provide the highest possible level of health services to all people in Uganda through delivery of promotive, preventive, curative, palliative and rehabilitative health services at all levels.'),
(16, '06', '015', 'Ministry of Trade, Industry and Cooperatives', 1, 'The mission of the Ministry is “To develop and promote a competitive and export-led Private Sector through accelerating industrial development for economic growth.”'),
(17, '04', '016', 'Ministry of Works and Transport', 1, 'To promote adequate, safe and well maintained Works and Transport Infrastructure and Services for Social Economic Development of Uganda\n'),
(18, '03', '017', 'Ministry of Energy and Mineral Development', 1, '“To ensure reliable, adequate and sustainable exploitation, management and utilization of energy and mineral resources in Uganda” '),
(19, '10', '018', 'Ministry of Gender, Labour and Social Development', 1, '\"To promote gender equality, social protection and transformation of the vulnerable\".'),
(20, '09', '019', 'Ministry of Water and Environment', 1, 'Sound management and sustainable utilization of water and Environment Resources for the present and future generations.'),
(21, '05', '020', 'Ministry of ICT and National Guidance', 1, 'To increase access and usage of ICT infrastructure and services throughout the country, ensure effective communication of government policies and programmes and promotion of a national ideology for socio economic transformation. '),
(22, '13', '021', 'East African Community', 1, 'To ensure that East Africans participate in and benefit from the East African Community integration\n'),
(23, '06', '022', 'Ministry of Tourism, Wildlife and Antiquities', 1, 'To develop and promote tourism, wildlife and cultural heritage resources for enhancement of Uganda as a preferred tourist destination, with accelerated sector contribution to the national economy'),
(24, '12', '101', 'Judiciary', 1, 'To administer Justice to all people in Uganda in an independent, impartial, accountable, efficient and effective manner'),
(25, '16', '102', 'Electoral Commission', 3, 'To efficiently organise, conduct and supervise regular, free , fair and transparent elections and referenda to enhance democracy and good governance'),
(26, '14', '103', 'Inspectorate of Government (IG)', 3, 'To promote good governance, accountability and rule of law in public office\n\n'),
(27, '15', '104', 'Parliamentary Commission', 3, 'Parliament conducts its business in Plenary and through Committees.  Under Article 90(1) of the Constitution, Parliament is empowered to appoint committees necessary for the efficient discharge of its functions. There are Sectoral, Standing, Select and Adhoc committees of Parliament.  Their roles and functions are described under the Rules of Procedure of the Parliament of Uganda.\nMission\n\"To achieve improved accountability, rule of law and national development within a multi-party democracy system in Uganda\"\n\n'),
(28, '12', '105', 'Law Reform Commission', 3, 'To reform and update laws in line with the social, cultural, economic needs and values of the people of Uganda'),
(29, '12', '106', 'Uganda Human Rights Commission', 3, '\n\nTo protect and promote fundamental Human Rights and freedoms in Uganda for sustainable development'),
(30, '08', '107', 'Uganda AIDS Commission', 3, 'To provide the overall leadership, coordination and management of the multi-sectoral HIV and AIDS Response\n\n   '),
(31, '13', '108', 'National Planning Authority', 3, 'To foster socio-economic transformation through establishing development planning systems and producing comprehensive and integrated development plans.'),
(32, '12', '109', 'Law Development Centre', 3, 'To promote the rule of law and access to justice through professional legal training, research, publications, community legal service and advocacy to legal practitioners, policy makers and the public.'),
(33, '06', '110', 'Uganda Industrial Research Institute', 3, 'The Mission of the Institute is \"To catalyze the socio-economic transformation of Uganda and the Region through enhanced Research and Development, and Technology use.\"'),
(34, '07', '111', 'Busitema University', 11, 'To provide high standard training, engage in quality research and outreach for Socio-economic transformation and sustainable development'),
(35, '14', '112', 'Ethics and Integrity', 2, 'To provide leadership in rebuilding ethics and integrity in the Ugandan society and coordinate national efforts against corruption.'),
(36, '04', '113', 'Uganda National Roads Authority', 3, 'To develop and maintain a national roads network that is responsive to the economic development needs of Uganda, to the safety of all road users, and to the environmental sustainability of the national roads corridors'),
(37, '08', '114', 'Uganda Cancer Institute', 3, 'Provision of state of the art cancer care and prevention by advancing knowledge, fostering the use of research as a resource in training and professional development'),
(38, '08', '115', 'Uganda Heart Institute', 3, 'The Uganda Heart institute Exists to serve as a centre of excellence for the provision of comprehensive medical services to patients with cardiovascular and thoracic disease and to offer opportunity for research and training in cardiovascular and thoracic medicine at an affordable cost so as to facilitate service delivery and enable continuous development of the Institute in itself'),
(39, '08', '116', 'National Medical Stores', 3, 'To effectively and efficiently supply Essential medicines and medical supplies to Public health facilities in Uganda.'),
(40, '06', '117', 'Uganda Tourism Board', 3, 'To develop, promote and coordinate a sustainable and competitive development of the tourism industry.'),
(41, '04', '118', 'Road Fund', 3, 'To provide effective and sustainable financing of maintenance for public roads, build partnerships with stakeholders and serve with integrity.'),
(42, '12', '119', 'Uganda Registration Services Bureau', 3, '“To promote, protect and register; business enterprises, intellectual property rights, civil matters, act as official receiver and collect Non Tax Revenue through an effective records management system”.'),
(43, '12', '120', 'National Citizenship and Immigration Control', 2, 'To control, regulate and facilitate citizenship and immigration for the development of Uganda'),
(44, '01', '121', 'Dairy Development Authority', 3, 'To provide efficient and effective development and regulatory services for increased production,processing and marketing of good quality milk and dairy products for improved incomes and food security in Uganda.'),
(45, '01', '122', 'Kampala Capital City Authority', 3, 'To Deliver Quality Service to the City                                                                  '),
(46, '02', '122', 'Kampala Capital City Authority', 3, 'To  Deliver quality services  to the city.                                                                         '),
(47, '04', '122', 'Kampala Capital City Authority', 3, 'To deliver quality services to the City.'),
(48, '07', '122', 'Kampala Capital City Authority', 3, 'To deliver quality services to the City.'),
(49, '08', '122', 'Kampala Capital City Authority', 3, 'To deliver quality services to the City.'),
(50, '09', '122', 'Kampala Capital City Authority', 3, 'To Deliver Quality Services to the City'),
(51, '10', '122', 'Kampala Capital City Authority', 3, 'To Deliver Quality Services to the City'),
(52, '13', '122', 'Kampala Capital City Authority', 3, 'To deliver quality services to the City'),
(53, '14', '122', 'Kampala Capital City Authority', 3, 'To Deliver Quality Services to the City'),
(54, '03', '123', 'Rural Electrification Agency (REA)', 3, 'Dedicated to socio-economic transformation of lives of Uganda’s rural communities by extending electricity services in an equitable and sustainable manner.     '),
(55, '10', '124', 'Equal Opportunities Commission', 3, 'To give effect to the State\'s mandate to eliminate discrimination and marginalization against any individual or groups of persons through taking affirmative action to redress imbalances and promote equal equal opportunities for all in all spheres of life.'),
(56, '01', '125', 'National Animal Genetic Res. Centre and Data Bank', 3, 'Optimize livestock production and productivity through animal breeding to improve food security and eradicate poverty in Uganda.'),
(57, '05', '126', 'National Information Technology Authority', 3, 'To transform Uganda into a knowledge-based society by leveraging IT as a strategic resource to enhance government services, enrich businesses and empower citizens.'),
(58, '07', '127', 'Muni University', 11, '“To provide quality education, generate knowledge; promote innovation and community empowerment for transformation”.'),
(59, '07', '128', 'Uganda National Examinations Board', 3, 'The Board’s Mission is: To ensure continued improvement of Quality, Validity and Reliability of Assessment and Evaluation of the Curriculum and Learner’s Achievements in an equitable manner.'),
(60, '14', '129', 'Financial Intelligence Authority (FIA)', 3, 'To foster the integrity of the financial system through effective detection and prevention of financial crimes.\n'),
(61, '14', '130', 'Treasury Operations', 2, NULL),
(62, '17', '130', 'Treasury Operations', 2, 'To effectively and efficiently manage Government statutory debt obligations, Investments and the Contingency Fund'),
(63, '14', '131', 'Auditor General', 3, 'To Audit and Report to Parliament and thereby make an Effective contribution to Improving Public Accountability and Value for Money spent.'),
(64, '07', '132', 'Education Service Commission', 2, 'The Mission of the Education Service Commission is:  “To provide professional and competent   Education Service personnel”.'),
(65, '12', '133', 'Office of the Director of Public Prosecutions', 2, 'To handle and prosecute criminal cases in a just, effective and efficient manner.'),
(66, '08', '134', 'Health Service Commission', 2, 'The Mission of the Health Service Commission is:\n\nTo build a fundamentally strong and competent human resource base for efficient and effective health services delivery.\n'),
(67, '07', '136', 'Makerere University', 11, 'To provide innovative teaching, learning, research and services responsive to national and global needs'),
(68, '07', '137', 'Mbarara University', 11, 'To provide quality and relevant education at national and international level with particular emphasis on science and Technology and its application to community development.'),
(69, '07', '138', 'Makerere University Business School', 11, 'To enable the future of our clients through creation and provision of knowledge.'),
(70, '07', '139', 'Kyambogo University', 11, 'To advance & promote knowledge & development of skills in science ,technology & education & such other fields having regard to quality, equity ,progress ,& transformation of society.'),
(71, '07', '140', 'Uganda Management Institute', 3, 'To excel in developing practical and sustainable administration, leadership and management capacity'),
(72, '14', '141', 'URA', 3, 'To Provide excellent revenue services with purpose and passion.'),
(73, '01', '142', 'National Agricultural Research Organisation', 3, 'To generate and disseminate appropriate, safe and cost effective technologies.'),
(74, '14', '143', 'Uganda Bureau of Statistics', 3, 'To coordinate the National Statistical System and provide quality demand driven statistics that support policy, decision making, research and development initiatives.'),
(75, '12', '144', 'Uganda Police Force', 2, 'To secure life and property in partnership with the public in a committed and professional manner in order to\npromote development'),
(76, '12', '145', 'Uganda Prisons', 2, 'To contribute to the protection and development of society by providing safe, secure, and humane custody of prisoners while placing human rights at the center of their correctional programs'),
(77, '13', '146', 'Public Service Commission', 2, 'To provide Government with competent human resources for effective Public Service delivery'),
(78, '13', '147', 'Local Government Finance Commission', 3, 'To offer Credible and evidence based advice to Government on financing of Local Governments. '),
(79, '12', '148', 'Judicial Service Commission', 2, 'To foster an accountable and effective judicial service through competence-based recruitment, disciplinary control, stakeholder engagement, and public and judicial education.'),
(80, '07', '149', 'Gulu University', 11, 'To be a leading academic institution for the promotion of rural transformation and industrialisation for sustainable development.'),
(81, '09', '150', 'National Environment Management Authority', 3, 'To promote and ensure sound environment management practices for sustainable development'),
(82, '08', '151', 'Uganda Blood Transfusion Service (UBTS)', 3, 'To provide sufficient and efficacious blood and blood components through voluntary blood donations for appropriate use in health care service delivery.'),
(83, '01', '152', 'NAADS Secretariat', 3, 'Presently NAADS mission to be reviewed to align it to NAADS’ new mandate. Presently; To increase farmers’ access to information, knowledge and technology for profitable agricultural production (as per NAADS Act 2001).'),
(84, '14', '153', 'PPDA', 3, '\"To promote the achievement of value for money in public procurement so as to contribute to National development.\"'),
(85, '06', '154', 'Uganda National Bureau of Standards', 3, 'The Mission of the Bureau is \"To provide standards , measurements and conformity assessment services for improved quality of life\".'),
(86, '01', '155', 'Uganda Cotton Development Organisation', 3, 'To promote and monitor production, processing and marketing of high value cotton and its by-products for the welfare of our society'),
(87, '02', '156', 'Uganda Land Commission', 3, 'To effectively hold and manage all Government land and property thereon and resolve historical land holding injustices'),
(88, '09', '157', 'National Forestry Authority', 3, 'To effectively and sustainably manage 506 CFR covering an area of over 1,265,742 hectares and supply high quality forestry related products and services to Government, local communities and private sector'),
(89, '11', '159', 'External Security Organisation', 2, 'To provide accurate, reliable and timely external intelligence of national interest to support policy making and implementation, law enforcement, defence and counter intelligence operations.'),
(90, '01', '160', 'Uganda Coffee Development Authority', 3, 'To facilitate increase in quality coffee production, productivity, and consumption'),
(91, '08', '161', 'Mulago Hospital Complex', 10, 'To be a center of excellence in providing super-specialized healthcare in Africa.'),
(92, '08', '162', 'Butabika Hospital', 10, 'To offer super specialized and general mental health services; conduct mental health training, mental health related research and provide support to mental health care services in the country'),
(93, '08', '163', 'Arua Referral Hospital', 10, 'Increasing access of the people within West Nile region to quality specialized health care services in a client centered manner,  with professionalism, integrity, and accountability in order to increase their productivity.'),
(94, '08', '164', 'Fort Portal Referral Hospital', 10, ' To increase access to all people in Rwenzori region to quality general and specialized health services.'),
(95, '08', '165', 'Gulu Referral Hospital', 10, 'Gulu Regional Referral Hospital (GRRH) exists to provide specialized health care, preventive, promotive, curative and rehabilitative services to the eight districts of the Acholi sub-region; conduct training, research and support supervision to general hospitals and lower level health facilities in the region.'),
(96, '08', '166', 'Hoima Referral Hospital', 10, 'To increase access to quality general and specialized health services to all people of Bunyoro Region'),
(97, '08', '167', 'Jinja Referral Hospital', 10, 'The Vision: A Centre of Excellence for Specialized Health Care.\nThe Mission: To Provide Quality Specialized, Accessible and Affordable Health Care Services. '),
(98, '08', '168', 'Kabale Referral Hospital', 10, 'A center of excellence  in the provision of general and specialized health services to the people of Kigezi sub region.'),
(99, '08', '169', 'Masaka Referral Hospital', 10, 'To provide highest  possible level of health services to all people in Masaka Region through quality  general and  specialized  health services delivery'),
(100, '08', '170', 'Mbale Referral Hospital', 10, 'To provide general and specialized, curative preventive, promotive, and rehabilitative services in the 14 Districts of Elgon catchment area '),
(101, '08', '171', 'Soroti Referral Hospital', 10, 'To increase access to all people in the region to quality general and specialised health services'),
(102, '08', '172', 'Lira Referral Hospital', 10, 'To be a Regional Center of Excellence in providing specialized and super specialized quality health services to men, women, children and persons with disabilities of all age groups, train health workers and conduct research with emphasis on maternal and child health in line with the requirements of Ministry of Health.'),
(103, '08', '173', 'Mbarara Referral Hospital', 10, 'To provide comprehensive, super specialized health services, conduct tertiary health training, research and contributing to the health policy. '),
(104, '08', '174', 'Mubende Referral Hospital', 10, 'To be a center of excellence in providing both specialized and general curative, preventive, health promotion and rehabilitative services to the community in our catchment area.'),
(105, '08', '175', 'Moroto Referral Hospital', 10, 'Vote Mission:\nTo increase access of all people in Karamoja Region and Beyond to quality general and specialized health services'),
(106, '08', '176', 'Naguru Referral Hospital', 10, 'TO PROVIDE COMPREHENSIVE GENERAL AND SPECIALIZED REFERRAL HEALTH SERVICES, TRAIN HEALTH PROFESSIONALS, AND CONDUCT RESEARCH\n'),
(107, '16', '201', 'Mission in New York', 12, ' To promote and protect Uganda’s interests abroad and within the United Nations '),
(108, '16', '202', 'Mission in England', 12, 'Contributing to the realization of economic/ commercial diplomacy, regional/ international peace and security and the well being of our people.'),
(109, '16', '203', 'Mission in Canada', 12, 'To protect Uganda\'s National Interests abroad'),
(110, '16', '204', 'Mission in India', 12, 'To protect Ugandas National interests Abroad.'),
(111, '16', '205', 'Mission in Egypt', 12, ' To make a contribution towards the Transformation and Development of Uganda '),
(112, '16', '206', 'Mission in Kenya', 12, 'To promote and protect Uganda’s national interest in Kenya, the region and International organizations\n\n'),
(113, '16', '207', 'Mission in Tanzania', 12, 'To Promote and Protect Ugandans Interests in the Region'),
(114, '16', '208', 'Mission in Nigeria', 12, 'Abuja Mission is both a bilateral & Multilateral Station.  Handles Bilateral and multilateral relations between Uganda and the Federal Republic of Nigeria (hereafter referred to as Nigeria) and other 14 West African States, which are all members of Economic States of West African States (ECOWAS).'),
(115, '16', '209', 'Mission in South Africa', 12, 'To create mutually strong bilateral relationships with Governments in Southern Africa.'),
(116, '16', '210', 'Mission in Washington', 12, 'Enhance the bilateral relationship between Uganda and the United States of America by promoting political and commercial interests ( Trade, Investment, Tourism, Technology Transfer and good relations)'),
(117, '16', '211', 'Mission in Ethiopia', 12, 'To Protect and Promote Uganda\'s interests abroad'),
(118, '16', '212', 'Mission in China', 12, 'To promote and protect Uganda\'s interest abroad'),
(119, '16', '213', 'Mission in Rwanda', 12, 'To promote and protect Uganda’s national interest in Rwanda, the region and International organisations.'),
(120, '16', '214', 'Mission in Geneva', 12, 'The Mission of the Permanent Mission is to represent Uganda and effectively participate in the work of Geneva based International Organizations such as the UN, WTO, UNCTAD, ITC, ILO, WIPO, WMO, OHCHR and UNCHR; to promote Uganda as a major tourist destination for the Swiss and as a profitable destination for Swiss Foreign Direct Investment; to enhance the value, volume and diversity of Uganda\'s exports to Switzerland; and to mobilize financial and other resources from Switzerland to Uganda.'),
(121, '16', '215', 'Mission in Japan', 12, 'Our mission is to promote and strengthen cooperation between the Governments and People of the Republic of Uganda and Japan and Republic of Korea.\nThe Republic of Uganda enjoys warm, cordial and mutually beneficial relations with Japan, Republic of Korea, and key objectives for the Embassy include the following below;\n•	To promote Uganda as a number one tourist and investment destination\n•	To solicit for ODA from the countries of accreditation.\n•	To solicit for Technical Assistance in the education, health, agriculture and ICT.\n•	To promote and protect Uganda\'s interests in Japan and the Republic of Korea.\n•	To acquire markets for Uganda’s products in the area of accreditation.\nTo protect and assist Ugandans living in the Mission’s area of accreditation\n'),
(122, '16', '216', 'Mission in Libya', 12, 'To promote and protect Uganda\'s interests abroad'),
(123, '16', '217', 'Mission in Saudi Arabia', 12, 'To promote and protect Uganda\'s interests abroad.'),
(124, '16', '218', 'Mission in Denmark', 12, 'To Promote and Protect Uganda\'s Interests in the Nordics.'),
(125, '16', '219', 'Mission in Belgium', 12, 'To promote, strengthen and protect Uganda\'s interest in Belgium, Luxemburg and Netherlands'),
(126, '16', '220', 'Mission in Italy', 12, 'To promote and protect Uganda\'s Interests in countries of accreditation and UN organisations (FAO, IFAD,WFP)\n'),
(127, '16', '221', 'Mission in DR Congo', 12, 'To Protect and Promote Uganda\'s interests in the Democratic Republic of Congo-Kinshasa ; and Ring States of Republic of Congo, Gabon, Central African Republic and Angola.'),
(128, '16', '223', 'Mission in Sudan', 12, 'To protect and promote Uganda\'s interests abroad.'),
(129, '16', '224', 'Mission in France', 12, 'To promote and protect Uganda\'s interests in France and all accredited countries and multilateral organisations'),
(130, '16', '225', 'Mission in Germany', 12, 'Berlin'),
(131, '16', '226', 'Mission in Iran', 12, 'To Promote and protect Uganda\'s Interests abroad'),
(132, '16', '227', 'Mission in Russia', 12, 'To promote and protect Uganda\'s interest in Russia and countries of Accreditation.'),
(133, '16', '228', 'Mission in Canberra', 12, 'To promote and protect Uganda’s national interest in Australia, New Zealand, Papua New Guinea and Fiji Islands'),
(134, '16', '229', 'Mission in Juba', 12, 'To promote and protect Uganda interests abroad'),
(135, '16', '230', 'Mission in Abu Dhabi ', 12, 'To develop durable trade links, and attract investments that adds value to the Uganda national economy'),
(136, '16', '231', 'Mission in Bujumbura', 12, 'To promote and protect Uganda\'s Interests abroad'),
(137, '16', '232', 'Consulate in Guangzhou', 12, 'To protect and promote Uganda\'s interest abroad'),
(138, '16', '233', 'Mission in Ankara', 12, 'To protect and promote Uganda\'s interest in Turkey.'),
(139, '16', '234', 'Mission in Somalia', 12, NULL),
(140, '16', '235', 'Mission in Malyasia', 12, 'To promote and Protect Uganda\'s image and interests in Malaysia and other Countries of accreditation.(Indonesia, Thailand, Phillipines, Vietnam, Lao PDR, Cambodia, Mynmar, Brunei-Darusalam)\n'),
(141, '16', '236', 'Consulate in Mombasa', 12, 'To promote and protect Uganda\'s interests Abroad'),
(142, '07', '301', 'Lira University', 11, 'To provide access to Quality Higher Education, Research and Conduct Professional Training for the Delivery of appropriate Health Services directed towards Sustainable Health Community and Environment. '),
(143, '09', '302', 'Uganda National Meteorological Authority', 3, 'To contribute to overall national development through provision of quality customer focused cost effective and timely information for weather and climate services to all users.'),
(144, '07', '303', 'National Curriculum Development Centre', 3, 'Develop and provide curricula and instructional materials for quality education through continuous manpower development, Research and stakeholder consultation'),
(145, '08', '304', 'Uganda Virus Research Institute (UVRI)', 3, 'To conduct scientific investigation on viral and other diseases to contribute to knowledge, policy and practice and engage in capacity development for improved public health'),
(146, '12', '305', 'Directorate of Government Analytical Laboratory', 2, 'To foster justice, public safety and health through provision of quality and timely scientific analytical, forensic and advisory services.'),
(147, '06', '306', 'Uganda Export Promotion Board', 3, 'The Mission of the Board is \"To Facilitate the Development, Diversification, Promotion and Coordination of all Export related activities that lead to Export Growth on Sustainable Basis.\"'),
(148, '07', '307', 'Kabale University', 11, 'To be an efficient people centred University that excels in generation and dissemination of relevant and quality knowledge. It aims at skill development and attitudinal change for lifelong learning.'),
(149, '07', '308', 'Soroti University', 11, 'To change the world by being a Fountain of knowledge and innovation that supports sustainable development and transformation of the society. We shall realize this goal through: \nEducating responsible, broad-minded persons to act as future visionaries in our society.\nStimulating innovations that surpass traditional boundaries. \nBuilding an open community of students, scholars and others, for free exchange of ideas to impact the society at large.\nDelivering learning that is active, creative and continuous.\nFighting society ills of poverty, disease, ignorance and unemployment'),
(150, '01', '500', '501-850 Local Governments', NULL, 'Transforming the sector from subsistence farming to commercial agriculture'),
(151, '02', '500', '501-850 Local Governments', NULL, NULL),
(152, '04', '500', '501-850 Local Governments', NULL, 'To increase household incomes through road construction'),
(153, '07', '500', '501-850 Local Governments', NULL, 'To provide for, support, guide, coordinate, regulate and promote quality education and sports to all persons in Uganda integration and national development.'),
(154, '08', '500', '501-850 Local Governments', NULL, 'To facilitate the attainment of a good standard of health by all people of Uganda in order to promote a healthy and productive life'),
(155, '09', '500', '501-850 Local Governments', NULL, '100% access to water and sanitation facilities to all communities and maintaining the integrity of the environment for sustainable development by the country'),
(156, '10', '500', '501-850 Local Governments', NULL, 'To promote Gender equality, social protection and transformation of the vulnerables'),
(157, '13', '500', '501-850 Local Governments', NULL, 'Our mission is to deliver on the Government policy of decentralization for effective service deliver to the citizenry. '),
(158, '14', '500', '501-850 Local Governments', NULL, NULL),
(159, '06', '500', '501-850 Local Governments', NULL, NULL),
(160, '07', '023', 'Ministry of Science,Technology and Innovation', 1, 'To provide leadership, an enabling environment and resources for scientific research and knowledge based development for industrialization, competitiveness and employment creation leading to a sustainable economy'),
(161, '12', '309', 'National Identification and Registration Authority (NIRA)', 3, 'To enhance growth, development and security of all people through complete Identification and Registration');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `api_tokens`
--
ALTER TABLE `api_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `api_tokens_id_expires_at_index` (`id`,`expires_at`),
  ADD KEY `api_tokens_user_id_foreign` (`user_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_levels`
--
ALTER TABLE `permission_levels`
  ADD PRIMARY KEY (`PID`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `settings_key_index` (`key`);

--
-- Indexes for table `social_logins`
--
ALTER TABLE `social_logins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `social_logins_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_created_at_index` (`created_at`),
  ADD KEY `users_username_index` (`username`),
  ADD KEY `users_status_index` (`status`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- Indexes for table `user_activity`
--
ALTER TABLE `user_activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_activity_user_id_foreign` (`user_id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `social_logins`
--
ALTER TABLE `social_logins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_activity`
--
ALTER TABLE `user_activity`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=324;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `api_tokens`
--
ALTER TABLE `api_tokens`
  ADD CONSTRAINT `api_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `social_logins`
--
ALTER TABLE `social_logins`
  ADD CONSTRAINT `social_logins_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `user_activity`
--
ALTER TABLE `user_activity`
  ADD CONSTRAINT `user_activity_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
